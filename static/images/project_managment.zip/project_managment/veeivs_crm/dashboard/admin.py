from django.contrib import admin
from .models import Project, Task

@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ("name", "status", "assigned_to", "deadline")
    search_fields = ("name", "assigned_to")
    list_filter = ("status",)

@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    list_display = ("title", "project", "is_completed")
    list_filter = ("is_completed",)
    search_fields = ("title",)
