from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('projects/', views.projects, name='projects'),
    path('tasks/', views.tasks, name='tasks'),
    path('leads/', views.leads, name='leads'),
    path('proposals/', views.proposals, name='proposals'),
    path('users/', views.users, name='users'),
    path('messages/', views.messages, name='messages'),
    path('clips/', views.clips, name='clips'),
    path('whiteboards/', views.whiteboards, name='whiteboards'),
    path('document/', views.document, name='document'),
    path('support/', views.support, name='support'),
    path('knowledgebase/', views.knowledgebase, name='knowledgebase'),
    path('other/', views.other, name='other'),
]
