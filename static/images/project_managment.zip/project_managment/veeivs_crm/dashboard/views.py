from django.shortcuts import render

def dashboard(request):
    # Mock data for the dashboard
    context = {
        'employee_count': 27,
        'stats_data': [
            {'title': 'Pending Projects', 'value': 22, 'percentage': 67, 'color': 'red'},
            {'title': 'Complete Projects', 'value': 15, 'percentage': 67, 'color': 'green'},
            {'title': 'On Hold Projects', 'value': 5, 'percentage': 67, 'color': 'yellow'},
        ],
        'projects': [
            {'status': 'High', 'date': '28-05-2025', 'time': '4:00 PM', 'project': 'Mars BPO', 'assigned': 2, 'result': 'Complete', 'result_color': 'green'},
            {'status': 'Low', 'date': '28-05-2025', 'time': '4:00 PM', 'project': 'Mars BPO', 'assigned': 2, 'result': 'On Hold', 'result_color': 'red'},
            {'status': 'Normal', 'date': '28-05-2025', 'time': '4:00 PM', 'project': 'Mars BPO', 'assigned': 2, 'result': 'Pending', 'result_color': 'orange'},
            {'status': 'Low', 'date': '28-05-2025', 'time': '4:00 PM', 'project': 'Mars BPO', 'assigned': 2, 'result': 'In Progress', 'result_color': 'blue'},
            {'status': 'High', 'date': '28-05-2025', 'time': '4:00 PM', 'project': 'Mars BPO', 'assigned': 2, 'result': 'In Progress', 'result_color': 'blue'},
        ],
        'interaction_data': [
            {'day': 'Mon', 'value': 60},
            {'day': 'Tue', 'value': 70},
            {'day': 'Wed', 'value': 80},
            {'day': 'Thu', 'value': 65},
            {'day': 'Fri', 'value': 75},
        ]
    }
    return render(request, 'dashboard/index.html', context)
from django.shortcuts import render

def dashboard(request):
    return render(request, 'dashboard.html')

def projects(request):
    return render(request, 'projects.html')

def tasks(request):
    return render(request, 'tasks.html')

def leads(request):
    return render(request, 'leads.html')

def proposals(request):
    return render(request, 'proposals.html')

def users(request):
    return render(request, 'users.html')

def messages(request):
    return render(request, 'messages.html')

def clips(request):
    return render(request, 'clipml')

def whiteboards(request):
    return render(request, 'whiteboards.html')

def document(request):
    return render(request, 'document.html')

def support(request):
    return render(request, 'support.html')

def knowledgebase(request):
    return render(request, 'knowledgebase.html')

def other(request):
    return render(request, 'other.html')
